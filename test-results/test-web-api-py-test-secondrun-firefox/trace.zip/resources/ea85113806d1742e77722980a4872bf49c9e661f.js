"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["experiences_me-stripe-wc_dist_index_js"],{38410:function(e,t,i){i.r(t),i.d(t,{MeStripeWC:function(){return z},MeStripeWCDisableSlideAnimationStyles:function(){return x},MeStripeWCFlipperLtrStyles:function(){return b},MeStripeWCFlipperRtlStyles:function(){return v},MeStripeWCFlippersStyles:function(){return g},MeStripeWCFlippersStylesDarkMode:function(){return f},MeStripeWCStyles:function(){return m},MeStripeWCTemplate:function(){return _},ToolingInfo:function(){return I}});var r=i(35883),n=i(63070),o=i(52175),s=i(54817),l=i(23335);var a=i(33940),p=i(22674),c=i(78923),d=i(29717);const h=c.i`
.me-stripe msft-horizontal-card-slider{left:-50px}`,u=c.i`
.me-stripe msft-horizontal-card-slider{right:-50px}`,m=c.i` :host{--neutral-fill-hover:#717171;--accent-fill-active:#717171;--accent-fill-hover:#717171;--type-ramp-base-line-height:15px;width:100%}.me-stripe{position:relative;background:transparent;border:solid #dcdcda;border-width:0 0 1px;height:auto;margin-bottom:4px}.me-stripe-compact.me-stripe{border:none}.me-stripe-windowshp{width:calc(100% - 14px)}.me-stripe msft-horizontal-card-slider{box-sizing:border-box;width:calc(100% + 100px);padding:0px 50px}.me-stripe msft-horizontal-card-slider::part(flipper-container){padding:5px 10px}.me-stripe msft-horizontal-card-slider::part(container){gap:0;display:flex;flex-flow:row;transition:transform 1s ease-in-out}`.withBehaviors(new p.O(h,u),(0,d.Uu)(c.i` .me-stripe{border:none}`)),g=" .flipper-next,.flipper-previous{height:86px;width:45px}.flipper-next:before,.flipper-previous:before{display:block;border-radius:0;border:none;width:150px;height:52px;margin-top:-5px;pointer-events:none;box-shadow:none !important}.flipper-next:before,.flipper-previous:before{height:86px;margin-top:0}.flipper-next:before{margin-left:-145px;background:linear-gradient(90deg,rgba(255,255,255,0) 0%,rgb(247 247 247) 70%,rgb(247 247 247) 100%)}.flipper-previous:before{margin-left:40px;opacity:0 !important;background:linear-gradient(90deg,#f7f7f7 0%,rgb(247 247 247) 30%,rgba(255,255,255,0) 100%)}",f=" @media (prefers-color-scheme:dark){.flipper-previous:before{display:none}.flipper-next:before{display:none}}",b=" .flipper-previous:before{margin-left:40px;background:linear-gradient(90deg,rgb(244,244,242) 0%,rgb(244,244,242) 30%,rgba(255,255,255,0) 100%)}.flipper-next:before{margin-left:-145px;background:linear-gradient(90deg,rgba(255,255,255,0) 0%,rgb(244,244,242) 70%,rgb(244,244,242) 100%)}",v=" .flipper-previous:before{margin-right:40px;background:linear-gradient(90deg,rgba(255,255,255,0) 0%,rgb(244 244 242) 70%,rgb(244,244,242) 100%)}.flipper-next:before{margin-right:-145px;background:linear-gradient(90deg,rgb(244,244,242) 0%,rgb(244,244,242) 30%,rgba(255,255,255,0) 100%)}",x=" div.viewport{scroll-behavior:initial}";var w=i(82898),y=i(7124);var $=i(55889),T=i(86522),S=i(79545),k=i(78951),C=i(78346),F=i(88249),H=i(99452),P=i(21930);class z extends C.l{constructor(){super(...arguments),this.telemetryObject=new k.D({name:"meStripe"}),this.isWindowsHP=()=>"windows"===$.jG.AppType}experienceConnected(){this.config.tiles&&((0,P.su)("TTVR.MeStripe",performance.now()),this.tiles=this.config.tiles,this.tiles.forEach((e=>{e.url=(0,T.h_)(e.url)})),this.addFlipperStyles())}connectedCallback(){super.connectedCallback(),this.tiles}getExperienceType(){return S.KpP}async addFlipperStyles(){const e=await(t="msft-horizontal-card-slider",i=this.shadowRoot,new Promise((e=>{const r=(0,y.Z)((()=>{e(i.querySelectorAll(t)),n.disconnect()})),n=new MutationObserver(r);n.observe(i,{childList:!0,subtree:!0})})));var t,i;if(null!=e&&e.length&&e[0].shadowRoot){let t=g;(0,F.cN)($.jG.CurrentMarket)?t+=v:t+=b,t+=f,this.config.disableSlideAnimation&&(t+=x),((e,t)=>{const i=document.createElement("style");i.innerHTML=t,e.prepend(i)})(e[0].shadowRoot,t)}}getNavigationButonTelemetryTag(e){return this.telemetryObject.addOrUpdateChild({name:e,action:w.Aw.Click,behavior:w.wu.Paginate,type:w.c9.ActionButton}).getMetadataTag()}}(0,a.gn)([H.LO],z.prototype,"tiles",void 0);var L=i(28904),M=i(32614);const O=c.i` .me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button .me-stripe-title-main-container .me-stripe-title-subtitle-container{position:relative;padding-right:6px;margin:0}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button .me-stripe-title-main-container .me-stripe-title-subtitle-container:before{content:".";position:absolute;top:-2px;right:2px;left:auto}`,N=c.i``,j=c.i` .me-stripe-logo-container{inset-inline-start:0}.me-stripe-tile-content{display:inline-block;vertical-align:top;overflow-y:hidden;width:140px;height:auto;padding-left:0}.me-stripe-tile-content.me-stripe-compact{height:70px;width:100px}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button{height:70px;padding:0}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button:hover{background-color:unset}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button .me-stripe-logo-container{border-radius:12px}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button .me-stripe-title-container{margin-top:2px}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button .me-stripe-title-main-container{font-weight:400;font-size:12px;max-width:100%;position:relative;line-height:normal}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button .me-stripe-title-main-container .me-stripe-title-main{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button .me-stripe-title-main-container .me-stripe-title-subtitle-container{position:relative;margin:0}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button .me-stripe-title-main-container .me-stripe-title-subtitle-container .me-stripe-title-subtitle{margin-top:0px}.me-stripe-tile-button{position:relative;cursor:pointer;text-decoration:none;color:rgb(43,43,43);outline-offset:0;display:flex;flex-flow:column;align-items:center;padding:13px 0 0 0;box-sizing:border-box;height:86px}.me-stripe-tile-button:hover{background-color:#E4E4E3;border-radius:6px}.me-stripe-tile-button:hover .me-stripe-title-main{text-decoration:underline}.me-stripe-logo-container{font-size:33px;font-weight:normal;position:relative;background:rgb(255,255,255);border-radius:4px;display:flex;align-items:center;justify-content:center;height:40px;width:40px;box-shadow:0px 2px 4px 0px rgba(0,0,0,0.14)}.me-stripe-tile-button .me-stripe-logo{height:24px;width:24px}.me-stripe-title-container{display:flex;padding-inline-start:0;width:100%}.me-stripe-title-main-container{font-weight:600;font-size:14px;line-height:14px;font-family:"Segoe UI Semibold","Segoe WP Semibold","Segoe WP","Segoe UI",Arial,Sans-Serif;color:#2b2b2b;line-height:20px;text-align:center;width:100%;overflow:hidden}.me-stripe-tile-button .me-stripe-title-main-container .me-stripe-title-subtitle-container{position:relative;left:0;right:0}.me-stripe-tile-button .me-stripe-title-subtitle{font-size:9px;font-weight:600;margin-top:-6px;color:#000000;opacity:1}`.withBehaviors(new p.O(N,O),(0,d.Uu)(c.i` .me-stripe-tile-button{color:var(--neutral-foreground-rest)}.me-stripe-logo-container{background:var(--neutral-stroke-rest)}.me-stripe-title-main-container,.me-stripe-tile-button .me-stripe-title-subtitle{color:var(--neutral-foreground-rest)}.me-stripe-tile-button:hover{background-color:var(--focus-stroke-outer);border-radius:6px}`));var W=i(49218),V=i(93703),D=i(558);const U=W.dy`<a class="me-stripe-tile-button" part="me-stripe-tile-button" href=${e=>e.tile.url} aria-label=${e=>e.tile.title} aria-expanded="false" @click=${(e,t)=>e.openNewTab(t)} @keypress=${(e,t)=>e.handleKeyDown(t)}><div class="me-stripe-logo-container"><img alt="" class="me-stripe-logo" src=${e=>e.logoSrc} /></div>${(0,V.g)((e=>e.tile.title),W.dy`<div class="me-stripe-title-container"><div class="me-stripe-title-main-container"><div class="me-stripe-title-main">${e=>e.tile.title}</div>${(0,V.g)((e=>e.tile.subTitle),W.dy`<div class="me-stripe-title-subtitle-container"><div class="me-stripe-title-subtitle">${e=>e.tile.subTitle.replace("{cbValue}",(0,D.V1)((0,D.B0)()))}</div></div>`)}</div></div>`)}</a>`,B=W.dy`<div class="me-stripe-tile-content${e=>0===e.tileIndex?" me-stripe-first-item":""} ${e=>e.useCompactMode?"me-stripe-compact":""}" data-t="${e=>e.telemetryTag}">${U}</div>`;var E=i(94537);let G=class extends L.H{constructor(){super(...arguments),this.openNewTab=e=>{let{event:t}=e;const{url:i}=this.tile;return t.preventDefault(),i?window.open(i,"_blank"):void 0},this.handleKeyDown=e=>{e.event.key!==E.kL||this.openNewTab(e)},this.imgFullUrl=e=>{const t=`//img-s-msn-com.akamaized.net/tenant/amp/entityid/${e}`;return(0,M.mL)(t,{width:27,height:27,enableDpiScaling:!1,format:M.D3.PNG})},this.getTelemetryTags=()=>{const{telemetryName:e,title:t,url:i,isAd:r}=this.tile,n=r?"LeadGen":"meStripe";return e?this.generateTelemetryTags(`${n}.${e}`,w.c9.Tile,t,i):null},this.generateTelemetryTags=(e,t,i,r)=>this.telemetryObject?this.telemetryObject.addOrUpdateChild({name:e,type:t,content:i?{headline:i}:void 0,overrideDestinationUrl:r||void 0}).getMetadataTag():null}connectedCallback(){super.connectedCallback(),this.tile&&(this.setTelemetryTag(),this.setLogoSrc())}setLogoSrc(){const{logoId:e,logoUrl:t=this.imgFullUrl(e)}=this.tile;this.logoSrc=t}setTelemetryTag(){this.telemetryTag=this.getTelemetryTags()}};(0,a.gn)([H.LO],G.prototype,"telemetryObject",void 0),(0,a.gn)([H.LO],G.prototype,"tileRect",void 0),(0,a.gn)([H.LO],G.prototype,"telemetryTag",void 0),(0,a.gn)([H.LO],G.prototype,"tile",void 0),(0,a.gn)([H.LO],G.prototype,"tileIndex",void 0),(0,a.gn)([H.LO],G.prototype,"logoSrc",void 0),G=(0,a.gn)([(0,L.M)({name:"me-stripe-tile",template:B,styles:j})],G);var A=i(89150);let R=0;const _=W.dy`<div class="${e=>`me-stripe ${e.config.useCompactMode?"me-stripe-compact":""} ${e.isWindowsHP()?"me-stripe-windowshp":""}`}" data-t="${e=>{var t;return null===(t=e.telemetryObject)||void 0===t?void 0:t.getMetadataTag()}}"><msft-horizontal-card-slider class="horizontal-slider-container" part="horizontal-slider-container" :flipperPreviousTelemetryTag=${e=>e.getNavigationButonTelemetryTag("leftarrow")} :flipperNextTelemetryTag=${e=>e.getNavigationButonTelemetryTag("rightarrow")}>${(0,A.rx)((e=>e.tiles),W.dy`<me-stripe-tile :tile=${e=>e} :tileIndex=${()=>R++} :useCompactMode=${(e,t)=>t.parent.config.useCompactMode} :telemetryObject=${(e,t)=>t.parent.telemetryObject} class="horizontal-item-container"></me-stripe-tile>`,{positioning:!0})}</msft-horizontal-card-slider></div>`,I={experienceConfigSchema:undefined};r.D.define(n.H.registry),o.D.define(n.H.registry),s.sG.define(l.j.registry)},25951:function(e,t,i){i.d(t,{Ns:function(){return d},Q:function(){return p},aK:function(){return u},af:function(){return h},d7:function(){return a},fr:function(){return l},hr:function(){return c}});var r=i(91046),n=i(55889),o=i(48955),s=i(23549);function l(){const e=(0,r.L)();return!!e&&("1"===e.get("vptest")||"true"===e.get("vptest")||"vp"===e.get("reqsrc"))}function a(e,t){return p(e,t,"shopping/product-tracking")}function p(e,t,i){if("local"===t&&window.location.origin.indexOf("localhost")>-1)return`http://127.0.0.1:3000/shopping/${e}.svg`;if(e){const r=t?`pr-${t}`:"latest",o=i?`${i}`:"shopping";return`${(0,n.Yq)().StaticsUrl}${r}/${o}/${e}.svg`}return""}function c(e){return e&&e.href&&(e.href=d(e.href)),!0}function d(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0;const i=(new Date).getTime()+t,r=(0,o.L)(),n=new URL(e);return n.searchParams.set("ts",i.toString()),n.searchParams.set("m_clk",`sid-${r}`),n.toString()}function h(e){return!!e&&/p4psearch\.1688\.com/.test(e)}function u(e,t){if(e&&e.href){const i=new URL(e.href);i.searchParams.set("m_ac","176674350"),i.searchParams.set("PageId",s.M0.getRequestId()),i.searchParams.set("ct",t),e.href=d(i.toString())}return!0}},558:function(e,t,i){i.d(t,{B0:function(){return n},V1:function(){return o}});var r=i(25951);function n(){let e=arguments.length>0&&void 0!==arguments[0]&&arguments[0];return function(){const e=new Date,t=e.getUTCDay(),i=e.getUTCHours();return!(1==t&&i>=18||5==t&&i<22||t>=2&&t<=4)||(0,r.fr)()}()||e?30:20}function o(e){return e.toString()+"%"}},54817:function(e,t,i){i.d(t,{V1:function(){return d},Au:function(){return b},sG:function(){return f}});var r=i(23335),n=i(33940),o=i(28904),s=i(99452),l=i(37802),a=i(59997),p=i(66779);function c(){return!("undefined"==typeof window||!window.document||window.isRenderServiceEnv)}class d extends o.H{constructor(){super(),this.direction=a.N.ltr,this.currentSlotElementWidth=0,this.currentContentGapSize=0,this.setFlippersVisabilityFromPageState=()=>{if(!c())return;const e=this.viewport.clientWidth,t=this.container.clientWidth;if(!e||!t||e>=t)return void this.setFlippersHiddenVisibility(!0,!0);const i=this.viewport.scrollLeft;0!==i?e+Math.abs(i)>=t?this.setFlippersHiddenVisibility(!1,!0):this.setFlippersHiddenVisibility(!1,!1):this.setFlippersHiddenVisibility(!0,!1)},this.handleResize=()=>{this.setFlippersVisabilityFromPageState()},this.handleResize=(0,l.Z)(this.handleResize,200)}connectedCallback(){super.connectedCallback(),this.direction=p.o.getValueFor(this),this.setFlippersVisabilityFromPageState(),window.addEventListener("resize",this.handleResize)}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("resize",this.handleResize)}handleChange(){this.direction=p.o.getValueFor(this),this.flipperNext.children[0].hidden=!1,this.flipperPrevious.children[0].hidden=!0}handleSlotContentChange(){if(!c())return;const e=this.viewportSlot.assignedElements();e.length>0&&(this.currentSlotElementWidth=e[0].clientWidth);const t=window.getComputedStyle(this.container).rowGap;this.currentContentGapSize=t?Number(t.replace(/px/,"")):0,this.setFlippersVisabilityFromPageState()}slideKeyPressHandler(e){if(!c())return;const t="rtl"!==this.direction;t||(e*=-1);const i=this.viewport.scrollLeft;if(t&&e<0&&0===i||!t&&e>0&&0===i)return;const r=this.viewport.clientWidth,n=this.container.clientWidth;if(r<=0||n<=0)return;if(r>=n)return void this.setFlippersHiddenVisibility(!0,!0);const o=e*this.getScrollDistance();(t&&e>0||!t&&e<0)&&((Math.abs(o)+Math.abs(i)>=n||n-(Math.abs(o)+Math.abs(i))<=r)&&this.hideFlipperNext(!0),this.hideFlipperPrevious(!1)),t&&e<0&&(o+i<=0&&this.hideFlipperPrevious(!0),this.hideFlipperNext(!1)),!t&&e>0&&(o+i>=0&&this.hideFlipperPrevious(!0),this.hideFlipperNext(!1)),window.requestAnimationFrame((()=>{this.viewport.scrollTo(this.viewport.scrollLeft+o,0)}))}hideFlipperNext(e){this.flipperNext.children[0].hidden=e}hideFlipperPrevious(e){this.flipperPrevious.children[0].hidden=e}setFlippersHiddenVisibility(e,t){this.hideFlipperPrevious(e),this.hideFlipperNext(t)}getOneElementUnit(){return this.currentSlotElementWidth+this.currentContentGapSize}getScrollDistance(){if(!c())return;const e=this.viewport.clientWidth;if(e<=0)return 0;const t=this.getOneElementUnit();if(!t||t<=0)return 0;const i=Math.floor(e/t)*t;return i<=0?t:i}}(0,n.gn)([s.LO],d.prototype,"direction",void 0),(0,n.gn)([s.LO],d.prototype,"flipperNextTelemetryTag",void 0),(0,n.gn)([s.LO],d.prototype,"flipperPreviousTelemetryTag",void 0);const h=i(78923).i` :host{--viewport-width:auto;--viewport-height:auto;--element-gap:12px;height:var(--viewport-height);overflow:hidden;width:var(--viewport-width);position:relative;display:flex}.flipper-container{position:absolute;right:0;left:0;top:0;bottom:0;padding:20px;display:flex;align-items:center;pointer-events:none;z-index:0}.viewport{height:var(--viewport-height);overflow-x:hidden;scroll-behavior:smooth;width:var(--viewport-width);white-space:nowrap}.container{display:flex;flex-direction:row;gap:var(--element-gap);width:max-content}.flipper-next{margin-inline-start:auto}.flipper-next,.flipper-previous{pointer-events:all;z-index:2}`;var u=i(49218),m=i(41472);const g=u.dy`<div ${(0,m.i)("viewport")} class="viewport" part="viewport" direction="${e=>e.direction?e.direction:"ltr"}"><div class="container" part="container" ${(0,m.i)("container")}><slot ${(0,m.i)("viewportSlot")} @slotchange=${e=>e.handleSlotContentChange()}></slot></div></div><div class="flipper-container" part="flipper-container"><slot ${(0,m.i)("flipperPrevious")} name="flipper-previous"><fluent-flipper direction="${e=>"rtl"===e.direction?"next":"previous"}" class="flipper-previous" part="flipper-previous" @click="${e=>e.slideKeyPressHandler(-1)}" data-t="${e=>e.flipperPreviousTelemetryTag}" hidden></fluent-flipper></slot><slot ${(0,m.i)("flipperNext")} name="flipper-next"><fluent-flipper direction="${e=>"rtl"===e.direction?"previous":"next"}" class="flipper-next" part="flipper-next" @click="${e=>e.slideKeyPressHandler(1)}" data-t="${e=>e.flipperNextTelemetryTag}" hidden></fluent-flipper></slot></div>`,f=d.compose({name:`${r.j.prefix}-horizontal-card-slider`,template:g,styles:h}),b=h},52175:function(e,t,i){i.d(t,{D:function(){return T}});var r=i(67776),n=i(63070),o=i(78923),s=i(27186),l=i(24484),a=i(67739),p=i(29717),c=i(22798),d=i(2658),h=i(42689),u=i(80260),m=i(26512),g=i(28632),f=i(10970),b=i(17993);const v=o.i`
    ${(0,s.j)("inline-flex")} :host {
        width: calc(${d.i} * 1px);
        height: calc(${d.i} * 1px);
        justify-content: center;
        align-items: center;
        margin: 0;
        position: relative;
        fill: currentcolor;
        color: ${h.C};
        background: transparent;
        border: none;
        outline: none;
        padding: 0;
    }

    :host::before {
        content: "";
        opacity: 0.8;
        background: ${u.jq};
        border: calc(${m.H} * 1px) solid ${g.ak};
        border-radius: 50%;
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
        bottom: 0;
        transition: all 0.1s ease-in-out;
    }

    .next,
    .previous {
        position: relative;
        ${""} width: 16px;
        height: 16px;
    }

    :host([disabled]) {
        opacity: ${f.V};
        cursor: ${l.H};
    }

    :host(:hover) {
        cursor: pointer;
    }

    :host(:hover)::before {
        background: ${u.Qp};
        border-color: ${g.QP};
    }

    :host(:${a.b}) {
        outline: none;
    }

    :host(:${a.b})::before {
        box-shadow: 0 0 0 1px ${b.yG} inset;
        border-color: ${b.yG};
    }

    :host(:active)::before {
        background: ${u.sG};
        border-color: ${g.c1};
    }

    :host::-moz-focus-inner {
        border: 0;
    }
`.withBehaviors((0,p.vF)(o.i`
            :host {
                background: ${c.H.Canvas};
            }
            :host .next,
            :host .previous {
                color: ${c.H.ButtonText};
                fill: currentcolor;
            }
            :host::before {
                background: ${c.H.Canvas};
                border-color: ${c.H.ButtonText};
            }
            :host(:hover)::before {
                forced-color-adjust: none;
                background: ${c.H.Highlight};
                border-color: ${c.H.ButtonText};
                opacity: 1;
            }
            :host(:hover) .next,
            :host(:hover) .previous {
                forced-color-adjust: none;
                color: ${c.H.HighlightText};
                fill: currentcolor;
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled])::before,
            :host([disabled]:hover)::before,
            :host([disabled]) .next,
            :host([disabled]) .previous,
            :host([disabled]:hover) .next,
            :host([disabled]:hover) .previous {
                forced-color-adjust: none;
                background: ${c.H.Canvas};
                border-color: ${c.H.GrayText};
                color: ${c.H.GrayText};
                fill: ${c.H.GrayText};
            }
            :host(:${a.b})::before {
                forced-color-adjust: none;
                border-color: ${c.H.Highlight};
                box-shadow: 0 0 0 2px ${c.H.Field},
                    0 0 0 4px ${c.H.FieldText};
            }
        `));var x=i(86158),w=i(49218);const y=(0,x._)({next:w.dy`
        <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M4.023 15.273L11.29 8 4.023.727l.704-.704L12.71 8l-7.984 7.977-.704-.704z"
            />
        </svg>
    `,previous:w.dy`
        <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M11.273 15.977L3.29 8 11.273.023l.704.704L4.71 8l7.266 7.273-.704.704z"
            />
        </svg>
    `});class $ extends r.N{}const T=$.compose({name:`${n.H.prefix}-flipper`,template:y,styles:v})},67776:function(e,t,i){i.d(t,{N:function(){return l}});var r=i(33940),n=i(28904),o=i(42590);const s="next";class l extends n.H{constructor(){super(...arguments),this.hiddenFromAT=!0,this.direction=s}keyupHandler(e){if(!this.hiddenFromAT){const t=e.key;"Enter"!==t&&"Space"!==t||this.$emit("click",e)}}}(0,r.gn)([(0,o.Lj)({mode:"boolean"}),(0,r.w6)("design:type",Boolean)],l.prototype,"disabled",void 0),(0,r.gn)([(0,o.Lj)({attribute:"aria-hidden",converter:o.bw}),(0,r.w6)("design:type",Boolean)],l.prototype,"hiddenFromAT",void 0),(0,r.gn)([o.Lj,(0,r.w6)("design:type",String)],l.prototype,"direction",void 0)},86158:function(e,t,i){i.d(t,{_:function(){return o}});var r=i(49218),n=i(17503);function o(e={}){const t={};return r.dy`
        <template
            role="button"
            aria-disabled="${e=>!!e.disabled||void 0}"
            tabindex="${e=>e.hiddenFromAT?-1:0}"
            @keyup="${(e,t)=>e.keyupHandler(t.event)}"
        >
            ${i=>function(e,i){let o=t[e];return o||(t[e]=o=r.dy`
                <span part="${e}" class="${e}">
                    <slot name="${e}">
                        ${(0,n.A)(i[e])}
                    </slot>
                </span>
            `),o}(i.direction,e)}
        </template>
    `}}}]);